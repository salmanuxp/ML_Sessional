conda activate mlpds

python == 3.9
jupyterlab
numpy




conda install -c anaconda ipykernel

python -m ipykernel install --user --name=mlpds